# Part 1: Theoretical Analysis

## Q1:

## Q2:

## Q3:

## Case Study:
