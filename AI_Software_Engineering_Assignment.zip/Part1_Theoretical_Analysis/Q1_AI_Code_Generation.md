Part 1: Theoretical Analysis (30%)
🔹 Q1: Explain how AI-driven code generation tools (e.g., GitHub Copilot) reduce development time. What are their limitations?
Answer:

AI-driven code generation tools like GitHub Copilot reduce development time by offering real-time code suggestions based on natural language prompts or the context of existing code. These tools leverage large language models trained on billions of lines of code to autocomplete functions, reduce boilerplate repetition, and recommend efficient solutions.

Benefits:

Speed: They accelerate coding by reducing the need to manually write routine code.

Learning aid: They help junior developers learn new syntax or libraries.

Contextual suggestions: Based on the project’s codebase, Copilot offers relevant suggestions.

Limitations:

Accuracy: Sometimes generates incorrect or insecure code.

Over-reliance: Developers may become dependent on AI without fully understanding the logic.

Bias: Trained on open-source data, which may carry legacy bugs or biases.

IP concerns: Generated code may unintentionally mirror copyrighted content.


