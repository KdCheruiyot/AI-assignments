Q2: Compare supervised and unsupervised learning in the context of automated bug detection.
Answer:

Supervised Learning uses labeled data (e.g., code samples marked as “buggy” or “clean”) to train models that classify or predict bugs.

Pros: High accuracy when trained well, excellent for known bug patterns.

Use Case: Predicting whether a commit will introduce a bug.

Unsupervised Learning analyzes unlabelled data to detect patterns and anomalies that may suggest bugs.

Pros: Useful when labeled data is scarce, detects novel bugs.

Use Case: Clustering similar error-prone modules or detecting anomalies in code complexity or commit frequency.

Conclusion: Supervised learning is ideal for structured bug detection with historical data, while unsupervised is better for discovering unknown or emerging issues
